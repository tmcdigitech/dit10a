from flask import Flask, send_from_directory, render_template
import sqlite3
import app_config

app = Flask(__name__)
app.config.from_object(app_config)

def get_db_connection():
    conn = sqlite3.connect(app_config.DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
@app.route('/index.html')
def index():
    return send_from_directory('templates','index.html')

@app.route('/')
@app.route('/demo.html')
def demo():
    return render_template('example.html')

@app.route('/generic.html')
def generic():
    return send_from_directory('templates','generic.html')

@app.route('/elements.html')
def elements():
    return send_from_directory('templates','elements.html')

@app.route('/top/<state>/<int:limit>')
def topNames(state, limit):
    db = get_db_connection()
    names = db.execute('SELECT * FROM gendered_names WHERE state=? ORDER BY total_babies DESC LIMIT ?', [state,limit,]).fetchall()
    # names = [{'name': 'Beryl'},{'name': 'Cheryl'},{'name': 'Leryl'},{'name': 'Geryl'},]
    return render_template('topX.html', state=state, names=names)



if __name__ == '__main__':
    app.run(host=app_config.HOST,port=app_config.PORT, debug=app_config.DEBUG_MODE)
