DEBUG_MODE = True
HOST = '127.0.0.1'
PORT = 5000
DB_FILE = 'data/babynames-gendered-2015.sqlite'
